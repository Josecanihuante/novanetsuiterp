# 🚀 Configuración de Perfiles en Google Antigravity IDE

## ¿Qué es esto?

Esta carpeta contiene la configuración completa de **5 perfiles de rol** para tu equipo en Google Antigravity IDE. Cada perfil define cómo el agente debe comportarse, qué estándares debe seguir y qué flujos de trabajo puede ejecutar.

---

## 📁 Estructura de archivos

```
.agent/
├── skills/
│   ├── arquitecto-software/
│   │   └── SKILL.md          ← Perfil: Arquitecto de Software
│   ├── developer-backend/
│   │   └── SKILL.md          ← Perfil: Developer Backend
│   ├── developer-frontend/
│   │   └── SKILL.md          ← Perfil: Developer Frontend (UI/UX)
│   ├── quality-assurance/
│   │   └── SKILL.md          ← Perfil: QA Engineer
│   └── experto-bases-datos/
│       └── SKILL.md          ← Perfil: Experto en Bases de Datos
├── rules/
│   ├── arquitecto.md         ← Reglas pasivas del Arquitecto
│   ├── backend.md            ← Reglas pasivas del Backend
│   ├── frontend.md           ← Reglas pasivas del Frontend
│   ├── qa.md                 ← Reglas pasivas del QA
│   └── base-datos.md         ← Reglas pasivas de Bases de Datos
└── workflows/
    ├── review-arquitectura.md
    ├── review-backend.md
    ├── review-frontend.md
    ├── review-qa.md
    └── review-base-datos.md
```

---

## ⚙️ Cómo instalar

### Opción A — Workspace específico (recomendado por proyecto)
Copia la carpeta `.agent/` a la raíz de tu proyecto:
```bash
cp -r .agent/ /ruta/de/tu/proyecto/
```

### Opción B — Global (disponible en todos los proyectos)
Copia las skills a la carpeta global de Antigravity:
```bash
# Skills globales
cp -r .agent/skills/* ~/.gemini/antigravity/skills/

# Workflows globales
cp -r .agent/workflows/* ~/.gemini/antigravity/global_workflows/
```

---

## 🎯 Cómo activar un perfil

En el chat de Antigravity, usa el comando `/` para invocar un workflow, o menciona el skill con `@`:

| Perfil | Comando de activación |
|---|---|
| Arquitecto de Software | `/review-arquitectura` o `@arquitecto-software` |
| Developer Backend | `/review-backend` o `@developer-backend` |
| Developer Frontend | `/review-frontend` o `@developer-frontend` |
| QA Engineer | `/review-qa` o `@quality-assurance` |
| Experto en BD | `/review-base-datos` o `@experto-bases-datos` |

---

## 🧠 Conceptos clave de Antigravity

| Concepto | ¿Qué es? | Ubicación |
|---|---|---|
| **Skill** | Capacidad reutilizable con instrucciones detalladas | `.agent/skills/<nombre>/SKILL.md` |
| **Rule** | Instrucción pasiva siempre activa (como un system prompt) | `.agent/rules/<nombre>.md` |
| **Workflow** | Procedimiento paso a paso invocable con `/comando` | `.agent/workflows/<nombre>.md` |
| **Artifact** | Documento generado por el agente (plan, diff, resultado) | Generado automáticamente |

---

## 💡 Tips de uso

- Usa **Planning Mode** para tareas complejas multi-archivo
- Usa **Fast Mode** para correcciones rápidas
- Puedes tener múltiples agentes corriendo en paralelo en el **Agent Manager**
- Revisa siempre el **Artifact del plan** antes de aprobar cambios mayores
- Las Rules se aplican automáticamente — no necesitas invocarlas

---

## 👥 Perfiles incluidos

1. **🏛️ Arquitecto de Software** — Diseño de sistemas, patrones, decisiones técnicas
2. **⚙️ Developer Backend** — APIs, lógica de negocio, microservicios
3. **🎨 Developer Frontend** — UI/UX, accesibilidad, diseño visual
4. **🔍 QA Engineer** — Testing, automatización, calidad de código
5. **🗄️ Experto en Bases de Datos** — Modelado, optimización, migraciones
